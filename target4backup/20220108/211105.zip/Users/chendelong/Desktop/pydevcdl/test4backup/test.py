import math
import torch
print(math.sqrt(2),torch.rand(1,1))